#include<windows.h>
#include<iostream>
using namespace std;


// Declare the global variable
static int  g_n;
CRITICAL_SECTION m_cs;


////////Thread One Function///////////////////
UINT ThreadOne(LPVOID lParam)
{

	// Lock the Critical section
	EnterCriticalSection(&m_cs); 
	for(int i=0;i<10;i++)
	{
		g_n++;
		cout << "Thread 1: " << g_n << "\n";
	}

	//Release the Critical section
	LeaveCriticalSection(&m_cs);
		
	// return the thread
	return 0;
}


////////Thread Two Function///////////////////
UINT ThreadTwo(LPVOID lParam)
{

	// Lock the Critical section
	EnterCriticalSection(&m_cs); 

	for(int i=0;i<10;i++)
	{
		g_n++;
		cout << "Thread 2: "<< g_n << "\n";
	}

	//Release the Critical section
	LeaveCriticalSection(&m_cs);

	// return the thread
	return 0;
}



int main()
{

	// Create the array of Handle
	HANDLE hThrd[2];
	
	//Thread ID's
	DWORD IDThread1, IDThread2;
	

	//Initilize the critical section
	InitializeCriticalSection(&m_cs); 


	// Create thredas use CreateThread function with NULL Security
	hThrd[0] = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) ThreadOne,(LPVOID)NULL,0,&IDThread1);       
	hThrd[1] = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) ThreadTwo,(LPVOID)NULL,0,&IDThread2); 

	// Wait for the main thread 
	WaitForMultipleObjects(2,hThrd,TRUE,INFINITE);

	// Delete critical Section
	DeleteCriticalSection(&m_cs);

	
	return 0;
}
