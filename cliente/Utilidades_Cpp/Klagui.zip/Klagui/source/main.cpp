#include <irrlicht.h>
#include "CHudProgressBar.h"
#include "CHudImageSkin.h"
#include "CHudSkinLoader.h"

using namespace irr;
using namespace scene;
using namespace io;
using namespace gui;
using namespace core;
using namespace video;

int main()
{
	IrrlichtDevice* device = createDevice(EDT_OPENGL, dimension2d<s32>(1024,768), 32, true);

	IVideoDriver* driver = device->getVideoDriver();
	ISceneManager* manager = device->getSceneManager();
	IFileSystem* filesys = device->getFileSystem();
	IGUIEnvironment* env = device->getGUIEnvironment();

	ICameraSceneNode* camera = manager->addCameraSceneNode();
	camera->setPosition(vector3df(45,45,15));
	camera->setTarget(vector3df(0,0,0));

	// Load GUI
	SImageGUISkinConfig guicfg = LoadGUISkinFromFile(filesys, driver, "../ui/guiskin.cfg");
	CHudImageSkin* skin = new CHudImageSkin(driver, env->getSkin());
	skin->loadConfig(guicfg);

	IGUIFont* font = env->getFont("../ui/fontlucida.png");

	if (font != 0)
		skin->setFont(font, EGDF_DEFAULT);

	env->setSkin(skin);

	skin->drop();

	IGUIWindow* win = env->addWindow(rect<s32>(60,60,260,260), false, L"This is a window");

	env->addButton( rect<s32>(10,10,100,50), 0, -1, L"Button!" )->setPressedImage(driver->getTexture("../ui/c.png" ));
	env->addCheckBox(true, rect<s32>(10,30,30,50), win );
	env->addStaticText(L"Checkbox", rect<s32>(30, 30, 120, 50), false, false, win);
	env->addEditBox(L"Edit box", rect<s32>(120,120,400,150) );
	IGUIListBox *lb = env->addListBox(rect<s32>(100,80,230,130), 0, -1, true);

	lb->addItem(L"teste");
	lb->addItem(L"teste3");
	lb->addItem(L"teste");
	lb->addItem(L"teste3");

	IGUIComboBox *cb = env->addComboBox(rect<s32>(100,280,230,330));

	cb->addItem(L"teste");
	cb->addItem(L"teste3");
	cb->addItem(L"teste");
	cb->addItem(L"teste3");

	IGUIScrollBar *sb = env->addScrollBar(true, rect<s32>(100,480,300,500));

	CHudProgressBar* bar = new CHudProgressBar(env->getRootGUIElement(), env, rect<s32>(10,150,610,180));
	bar->setProgress(0.35f);
	bar->drop();

	float progress = 0.0f;
	bool increaseProgress = true;

	s32 lastTime = device->getTimer()->getTime();

	while ( device->run() )
	{
		driver->beginScene(true, true, SColor(0,25,25,25));
		manager->drawAll();
		env->drawAll();
		driver->endScene();

		s32 newTime = device->getTimer()->getTime();
		s32 deltaTime = newTime - lastTime;
		lastTime = newTime;

		if (increaseProgress)
			progress += deltaTime * 0.0002f;
		else
			progress -= deltaTime * 0.0002f;

		if (progress > 1.0f)
		{
			progress = 1.0f;
			increaseProgress = false;
		}
		else if (progress < 0.0f)
		{
			progress = 0.0f;
			increaseProgress = true;
		}

		bar->setProgress(progress);
	}

	device->drop();

	return 0;
}