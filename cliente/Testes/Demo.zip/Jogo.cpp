/*
Procedimentos do Jogo
*/

#include "Personagem.h"
#include "Tabuleiro.h"
#include "Jogo.h"
#include <iostream>

CJogo_Tabuleiro::CJogo_Tabuleiro()
{
}

CJogo_Tabuleiro::~CJogo_Tabuleiro()
{
}

void CJogo_Tabuleiro::InserirPersonagens()
{
	
	m_Data_Boneco.Load("boneco\\modelo.md2", "boneco\\boneco.tga", "boneco\\machado.md2", "boneco\\machado.tga", 0.03f);

	Boneco.p_tipo = PERSONAGEM_BONECO;
	Boneco.p_coluna = 3;
	Boneco.p_linha = 0;
	Boneco.p_inPlay = true;
	Boneco.p_modelo = m_Data_Boneco.GetInstance();
}
void CJogo_Tabuleiro::Iniciar()
{
	m_Tabuleiro = new CTabuleiro;
	m_Tabuleiro->Iniciar();
	InserirPersonagens();

	m_Tabuleiro->SetarPersonagemQuadrante(Boneco.p_linha, Boneco.p_coluna, Boneco.p_tipo);

	m_ColunaAtual	   = -1;
	m_LinhaAtual	   = -1;
	m_EstadoJogo	   = ESTADO_ESPERA;
}

void CJogo_Tabuleiro::AtualizarJogo(float dt)
{
	m_Tabuleiro->LimparPersonagensTabuleiro();

		if (Boneco.p_inPlay)
		{
			if (Boneco.p_modelo)
				Boneco.p_modelo->Animate(dt);

			m_Tabuleiro->SetarPersonagemQuadrante(Boneco.p_linha, Boneco.p_coluna, Boneco.p_tipo);
		}

	AtualizarMovimento(dt);
}

void CJogo_Tabuleiro::Renderizar()
{
	if (Boneco.p_inPlay)
	{
		if (Boneco.p_modelo)
		{
			if (m_EstadoJogo != ESTADO_MOVIMENTO)
				Boneco.p_modelo->Move((float)Boneco.p_linha+0.5f, 0.0f,(float)Boneco.p_coluna+0.5f);

			Boneco.p_modelo->Render();
		}
	}
}

void CJogo_Tabuleiro::Desmontar()
{
	m_Tabuleiro->Desmontar();

	if (Boneco.p_modelo)
	{
		Boneco.p_modelo->Unload();
		delete Boneco.p_modelo;
	}

	delete m_Tabuleiro;
}

bool CJogo_Tabuleiro::PersonagemMovimentando(int linha, int coluna)
{
	if (((Boneco.p_linha == linha) && (Boneco.p_coluna == coluna)) && (Boneco.p_inPlay))
		return true;
	else
		return false;
}

void CJogo_Tabuleiro::AtualizarMovimento(float dt)
{
	if (m_EstadoJogo == ESTADO_MOVIMENTO)
	{
		if (Boneco.p_modelo->GetAnimation() == CMD2Instance::_STATIC)
		{
			Boneco.p_modelo->Rotate(m_AnguloRotacao);
			Boneco.p_modelo->SetAnimation(CMD2Instance::RUN);
		}
		else if (m_DistanciaMovimento > 0.75)
		{
			m_PosicaoPersonagem += m_VelocidadePersonagem * dt;
			m_DistanciaMovimento -= m_VelocidadePersonagem.Length() * dt;
			m_LinhaAtualMovimento = m_PosicaoPersonagem.x;
			m_ColunaAtualMovimento = m_PosicaoPersonagem.z;

			Boneco.p_modelo->Rotate(m_AnguloRotacao);
			Boneco.p_modelo->Move(m_PosicaoPersonagem.z, 0.0, m_PosicaoPersonagem.x);
		}
		else if ((m_DistanciaMovimento <= 0.75) && (m_DistanciaMovimento > 0.0))
		{
			m_PosicaoPersonagem += m_VelocidadePersonagem * dt;
			m_DistanciaMovimento -= m_VelocidadePersonagem.Length() * dt;
			m_LinhaAtualMovimento = m_PosicaoPersonagem.x;
			m_ColunaAtualMovimento = m_PosicaoPersonagem.z;

			Boneco.p_modelo->Rotate(m_AnguloRotacao);
			Boneco.p_modelo->Move(m_PosicaoPersonagem.z, 0.0, m_PosicaoPersonagem.x);
		}
		else
		{
			Boneco.p_coluna = (int)m_PosicaoPersonagem.x;
			Boneco.p_linha = (int)m_PosicaoPersonagem.z;
			Boneco.p_modelo->SetAnimation(CMD2Instance::IDLE);

			m_EstadoJogo = ESTADO_ESPERA;
		}
	}
}

void CJogo_Tabuleiro::SetarAnimacao(int acao)
{/*
	0 IDLE,
	1 RUN,
	2 ATTACK,
	3 PAIN1,
	4 PAIN2,
	5 PAIN3,
	6 JUMP,
    7 FLIPOFF,
    8 SAULTE,
    9 TAUNT,
    10 WAVE,
    11 POINT,
    12 CROUCH_IDLE,
    13 CROUCH_WALK,
    14 CROUCH_ATTACK,
    15 CROUCH_PAIN,
    16 CROUCH_DEATH,
    17 DEATH1,
    18 DEATH2,
    19 DEATH3
	*/

    int aux = Boneco.p_modelo->GetAnimation();

	switch (acao)
	{
		case 2: // Atacar
			Boneco.p_modelo->SetAnimation(CMD2Instance::ATTACK, aux);
			break;
		case 11: // Pontuacao
			Boneco.p_modelo->SetAnimation(CMD2Instance::POINT, aux);
			break;
		case 6: // Pular
			Boneco.p_modelo->SetAnimation(CMD2Instance::JUMP, aux);
			break;
		case 8: // Cumprimentar
			Boneco.p_modelo->SetAnimation(CMD2Instance::SAULTE, aux);
			break;
		case 10: // Adeus
			Boneco.p_modelo->SetAnimation(CMD2Instance::WAVE, aux);
			break;
		case 17: // Morte
			Boneco.p_modelo->SetAnimation(CMD2Instance::DEATH2, CMD2Instance::_STATIC);
			break;
		case 14: // Ataque CROUCH
			Boneco.p_modelo->SetAnimation(CMD2Instance::CROUCH_ATTACK, aux);
			break;
		case 9: // TAUNT
			Boneco.p_modelo->SetAnimation(CMD2Instance::TAUNT, aux);
			break;
		case 13: // CROUCH_WALK
			Boneco.p_modelo->SetAnimation(CMD2Instance::CROUCH_WALK, CMD2Instance::_REPEAT);
			break;
		case 1: // RUN
			Boneco.p_modelo->SetAnimation(CMD2Instance::RUN, CMD2Instance::_REPEAT);
			break;
	};
}

void CJogo_Tabuleiro::MoverPersonagem(int destRow, int destCol)
{
	m_LinhaInicialMovimento = Boneco.p_linha + 0.5f;
	m_ColunaInicialMovimento = Boneco.p_coluna + 0.5f;
	m_LinhaFinalMovimento   = destRow + 0.5f;
	m_ColunaFinalMovimento   = destCol + 0.5f;

	m_LinhaAtualMovimento = m_LinhaInicialMovimento;
	m_ColunaAtualMovimento = m_ColunaInicialMovimento;

	m_PosicaoPersonagem = CVector(m_ColunaInicialMovimento, 0.0, m_LinhaInicialMovimento);

	m_VelocidadePersonagem = CVector(m_ColunaFinalMovimento - m_ColunaInicialMovimento, 0.0, m_LinhaFinalMovimento - m_LinhaInicialMovimento);
	
	m_DistanciaMovimento = m_VelocidadePersonagem.Length();

	m_VelocidadePersonagem.Normalize();

	if (m_VelocidadePersonagem.z > 0)
		m_AnguloRotacao = RAD2DEG(m_VelocidadePersonagem.Angle(CVector(1.0, 0.0, 0.0))) - 90.0f;
	else
		m_AnguloRotacao = RAD2DEG(m_VelocidadePersonagem.Angle(CVector(-1.0, 0.0, 0.0))) + 90.0f;

	if (m_EstadoJogo == ESTADO_MOVIMENTO)
	{
		Boneco.p_modelo->SetAnimation(CMD2Instance::RUN);
	}
} 

void CJogo_Tabuleiro::MoverPersonagemDireto(int LinhaDestino, int ColunaDestino)
{
	Boneco.p_linha = LinhaDestino;
	Boneco.p_coluna = ColunaDestino;
}

bool CJogo_Tabuleiro::EhMovimentoValido(int novaLinha, int novaColuna)
{
	return true; // todos movimentos s�o v�lidos
}

void CJogo_Tabuleiro::OnSelection(float coluna, float linha)
{
	if (m_EstadoJogo == ESTADO_ESPERA)
	{
		if (((coluna <= 8.0) && (coluna >= 0.0)) && ((linha >= 0.0) && (linha <= 8.0)))
		{
			if (EhMovimentoValido((int)linha, (int)coluna))
			{
				m_EstadoJogo = ESTADO_MOVIMENTO;
				MoverPersonagem((int)linha, (int)coluna);
			}

			m_LinhaAtual = -1;
			m_ColunaAtual = -1;
		}
	}
}