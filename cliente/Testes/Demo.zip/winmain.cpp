/*
Procedimentos da janela do Demo
*/

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#include <windows.h>
#include <string>
#include <gl/gl.h>
#include <gl/glu.h>

#include "TextureMgr.h"
#include "md2.h"
#include "OpenGLConfig.h"
#include "Jogo.h"
#include "timer.h"

bool exiting = false;
long windowWidth = 1024;
long windowHeight = 768;
long windowBits = 24;
bool fullscreen = false;
int mouseX, mouseY;
HDC hDC;

OpenGLConfig *g_glRender = NULL;
CHiResTimer *g_hiResTimer = NULL;
CJogo_Tabuleiro *g_jogo = NULL;

void SetupPixelFormat(HDC hDC)
{
	int pixelFormat;

	PIXELFORMATDESCRIPTOR pfd =
	{	
		sizeof(PIXELFORMATDESCRIPTOR),	
			1,							
			PFD_SUPPORT_OPENGL |		
			PFD_DRAW_TO_WINDOW |		
			PFD_DOUBLEBUFFER,		
			PFD_TYPE_RGBA,				
			32,							
			0, 0, 0, 0, 0, 0,			
			0,							
			0,							
			0,							
			0, 0, 0, 0,					
			16,							
			0,							
			0,							
			PFD_MAIN_PLANE,				
			0,							
			0, 0, 0,					
	};

	pixelFormat = ChoosePixelFormat(hDC, &pfd);
	SetPixelFormat(hDC, pixelFormat, &pfd);
}

LRESULT CALLBACK MainWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HDC hDC;
	static HGLRC hRC;
	int height, width;
	int xPos, yPos;
	double x, y, z;
	char str[40] = {'\0'};

	switch (uMsg)
	{	
	case WM_CREATE:			
		hDC = GetDC(hWnd);
		SetupPixelFormat(hDC);
		hRC = wglCreateContext(hDC);
		wglMakeCurrent(hDC, hRC);
		break;

	case WM_DESTROY:			
	case WM_QUIT:
	case WM_CLOSE:				

		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);

		PostQuitMessage(0);
		break;

	case WM_SIZE:
		height = HIWORD(lParam);	
		width = LOWORD(lParam);

		g_glRender->ConfigurarProjecao(width, height);
		break;

	case WM_ACTIVATEAPP:		
		break;

	case WM_PAINT:				
		PAINTSTRUCT ps;
		BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;

	case WM_LBUTTONDOWN:		
		xPos = LOWORD(lParam); 
		yPos = HIWORD(lParam);
		g_glRender->DetectarIntersecao(xPos, yPos, x, y, z);
		g_jogo->OnSelection((float)z, (float)x);
		break;

	case WM_RBUTTONDOWN:

		break;

	case WM_MOUSEMOVE:			
		break;

	case WM_LBUTTONUP:			
		break;

	case WM_RBUTTONUP:			
		break;

	case WM_KEYUP:
		break;

	case WM_KEYDOWN:
		int fwKeys;
		LPARAM keyData;
		fwKeys = (int)wParam;    
		keyData = lParam;         

		switch(fwKeys)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		case VK_SPACE: 
			g_jogo->SetarAnimacao(6);
			break;
		case VK_F1: 
			g_jogo->SetarAnimacao(11);
			break;
		case VK_F2: 
			g_jogo->SetarAnimacao(17);
			break;
		case VK_F3: 
			g_jogo->SetarAnimacao(8);
			break;
		case VK_F4: 
			g_jogo->SetarAnimacao(2);
			break;
		case VK_F5: 
			g_jogo->SetarAnimacao(14);
			break;
		case VK_F6: 
			g_jogo->SetarAnimacao(9);
			break;
		case VK_F7: 
			g_jogo->SetarAnimacao(7);
			break;
		case VK_F8: 
			g_jogo->SetarAnimacao(13);
			break;
		case VK_F9: 
			g_jogo->SetarAnimacao(1);
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX windowClass;		
	HWND	   hwnd;			
	MSG		   msg;				
	DWORD	   dwExStyle;		
	DWORD	   dwStyle;			
	RECT	   windowRect;

	g_glRender = new OpenGLConfig;
	g_hiResTimer = new CHiResTimer;
	g_jogo = new CJogo_Tabuleiro;

	windowRect.left=(long)0;						
	windowRect.right=(long)windowWidth;	
	windowRect.top=(long)0;							
	windowRect.bottom=(long)windowHeight;	

	windowClass.cbSize			= sizeof(WNDCLASSEX);
	windowClass.style			= CS_HREDRAW | CS_VREDRAW;
	windowClass.lpfnWndProc		= MainWindowProc;
	windowClass.cbClsExtra		= 0;
	windowClass.cbWndExtra		= 0;
	windowClass.hInstance		= hInstance;
	windowClass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);	
	windowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);		
	windowClass.hbrBackground	= NULL;								
	windowClass.lpszMenuName	= NULL;								
	windowClass.lpszClassName	= "GLClass";
	windowClass.hIconSm			= LoadIcon(NULL, IDI_WINLOGO);		

	// register the windows class
	if (!RegisterClassEx(&windowClass))
		return 0;

	dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			
	dwStyle=WS_OVERLAPPEDWINDOW;					

	AdjustWindowRectEx(&windowRect, dwStyle, FALSE, dwExStyle);		

	hwnd = CreateWindowEx(NULL, "GLClass", "Demo - Eduardo Fantini", dwStyle | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
		0, 0, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, NULL, NULL, hInstance, NULL);

	hDC = GetDC(hwnd);

	if (!hwnd)
		return 0;

	ShowWindow(hwnd, SW_SHOW);		
	UpdateWindow(hwnd);				

	if (!g_glRender->Iniciar())
	{
		MessageBox(NULL, "OpenGLConfig::Iniciar() Erro! Faltam texturas.", "OpenGLConfig class failed to Iniciarialize!", MB_OK);
		return -1;
	}

	g_hiResTimer->Iniciar();
	g_jogo->Iniciar();
	g_glRender->LinkarJogo(g_jogo);

	while (!exiting)
	{
		g_glRender->Preparar(g_hiResTimer->GetElapsedSeconds(1));
		g_glRender->Renderizar();
		SwapBuffers(hDC);

		while (PeekMessage (&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage (&msg, NULL, 0, 0))
			{
				exiting = true;
				break;
			}

			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}

	delete g_jogo;
	delete g_hiResTimer;
	delete g_glRender;

	return (int)msg.wParam;
}