/*
Biblioteca para comandos OpenGL
*/

#ifndef __GL_COMPONENT
#define __GL_COMPONENT

#include "vector.h"

class CMD2Modelo;
class CJogo_Tabuleiro;
class CTextureMgr;


class OpenGLConfig
{

private:

	CTextureMgr m_GerenciadorTexturas;
	CJogo_Tabuleiro *m_Jogo;
	CVector m_PosicaoVista;

	int m_LarguraJanela;
	int m_AlturaJanela;

	unsigned int m_TabuleiroDL;
	unsigned int m_TexturaTabuleiro;
	unsigned int m_TexturaMesa;

	char m_VistaAtual;

	void GerarTabuleiroDL();
	void RenderTabuleiro();
	void RenderBonecos();
	void RenderMesa();

public:

	OpenGLConfig();
	virtual ~OpenGLConfig();
	bool Iniciar();
	bool Sair();
	void LinkarJogo(CJogo_Tabuleiro *Jogo);
	void ConfigurarProjecao(int largura, int altura);
	void Preparar(float dt);
	void Renderizar();
	void DetectarIntersecao(int winx, int winy, double &x, double &y, double &z);
};

#endif