/*
Procedimentos do tabuleiro
*/

#include "Tabuleiro.h"

CTabuleiro::CTabuleiro()
{
}

CTabuleiro::~CTabuleiro()
{
}

void CTabuleiro::Iniciar()
{
	LimparPersonagensTabuleiro();
}

unsigned char CTabuleiro::IdentificarPersonagemQuadrante(int linha, int coluna)
{
	if (((linha >= 0) && (linha < 8)) && ((coluna >= 0) && (coluna < 8)))
		return m_MatrizTabuleiro[linha][coluna];
	else
		return PERSONAGEM_NULL;
}

void CTabuleiro::SetarPersonagemQuadrante(int linha, int coluna, unsigned char t_personagem)
{
	if (((linha >= 0) && (linha < 8)) && ((coluna >= 0) && (coluna < 8)))
	{
		m_MatrizTabuleiro[linha][coluna] = t_personagem;
	}
}

void CTabuleiro::LimparPersonagensTabuleiro()
{
	int coluna, linha;

	for (coluna = 0; coluna < 8; coluna++)
		for (linha = 0; linha < 8; linha++)
		{
			m_MatrizTabuleiro[linha][coluna] = PERSONAGEM_NULL;
		}
}

void CTabuleiro::Desmontar()
{
}