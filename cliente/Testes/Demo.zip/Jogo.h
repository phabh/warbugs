/*
Biblioteca do jogo
*/

#ifndef __JOGO_H
#define __JOGO_H

#include "vector.h"
#include "md2.h"
#include "Personagem.h"
#include "Tabuleiro.h"


const char ESTADO_ESPERA    = 0x01;	
const char ESTADO_MOVIMENTO = 0x02;	

class CJogo_Tabuleiro
{

private:

	CTabuleiro *m_Tabuleiro;
	Personagem  Boneco;
	CMD2Data	m_Data_Boneco;

	int			m_PersonagemSelecionado;
	int			m_LinhaAtual;
	int			m_ColunaAtual;
	char		m_EstadoJogo;

	float		m_LinhaInicialMovimento;	
	float		m_ColunaInicialMovimento;
	float		m_LinhaFinalMovimento;		
	float		m_ColunaFinalMovimento;
	float		m_LinhaAtualMovimento;
	float		m_ColunaAtualMovimento;
	float		m_DistanciaMovimento;
	float		m_AnguloRotacao;	

	CVector		m_VelocidadePersonagem;
	CVector		m_PosicaoPersonagem;	


	void InserirPersonagens();
	void MoverPersonagem(int LinhaDestino, int ColunaDestino);
	void MoverPersonagemDireto(int LinhaDestino, int ColunaDestino);
	bool PersonagemMovimentando(int linha, int coluna);
	void AtualizarMovimento(float dt);

public:

	CJogo_Tabuleiro();
	virtual ~CJogo_Tabuleiro();
	void Iniciar();
	void AtualizarJogo(float dt);
	void Renderizar();
	void Desmontar();
	void OnSelection(float row, float col);
	void SetarAnimacao(int acao);
	CTabuleiro *SetarTabuleiro() { return m_Tabuleiro; }
	bool EhMovimentoValido(int newRow, int newCol);	
};

#endif