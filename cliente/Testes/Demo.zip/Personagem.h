/*
Biblioteca para estruturar Personagens
*/

#ifndef __PERSONAGEM_H
#define __PERSONAGEM_H

#include "md2.h"

#define PERSONAGEM_IDLE		0
#define PERSONAGEM_MOVING	1
#define PERSONAGEM_DYING	2

struct Personagem
{
	unsigned char	p_tipo;		// Tipo
	bool			p_inPlay;   // Em A��o
	int				p_linha;	// Linha
	int				p_coluna;	// Coluna
	char			p_estado;	// IDLE, MOVING, DYING
	CMD2Instance   *p_modelo;   // Modelo MD2
};

#endif