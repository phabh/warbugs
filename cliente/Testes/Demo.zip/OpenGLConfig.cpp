/*
Procedimentos de OpenGL
*/

#ifdef _WINDOWS
#include <windows.h>
#endif

#include <gl/gl.h>
#include <gl/glu.h>
#include <math.h>
#include <time.h>
#include <cmath>
#include <cstdio>
#include "vector.h"
#include "Plane.h"

#include "CTargaImage.h"
#include "md2.h"
#include "TextureMgr.h"
#include "Jogo.h"
#include "OpenGLConfig.h"

#pragma warning(disable:4244)
#pragma warning(disable:4305)
#pragma warning(disable:4996)


OpenGLConfig::OpenGLConfig()
{
}

OpenGLConfig::~OpenGLConfig()
{
}

bool OpenGLConfig::Iniciar()
{	
	if (!m_GerenciadorTexturas.LoadTextures("texturas.dat"))
		return false;

	glEnable(GL_TEXTURE_2D);

	m_TexturaMesa = m_GerenciadorTexturas.GetTextureID("mesa");
	m_TexturaTabuleiro = m_GerenciadorTexturas.GetTextureID("tabuleiro");
	m_GerenciadorTexturas.Bind(m_TexturaTabuleiro);

	GerarTabuleiroDL();

	m_PosicaoVista = CVector(-4.0, 3.5, 4.0);

	return true;
}

bool OpenGLConfig::Sair()
{
	m_GerenciadorTexturas.ReleaseTextures();

	glDeleteLists(m_TabuleiroDL, 1);

	return true;
}

void OpenGLConfig::LinkarJogo(CJogo_Tabuleiro *Jogo)
{
	m_Jogo = Jogo;
}

void OpenGLConfig::ConfigurarProjecao(int largura, int altura)
{
	if (altura == 0)					
		altura = 1;					

	glViewport(0, 0, largura, altura);		
	glMatrixMode(GL_PROJECTION);			
	glLoadIdentity();						

	gluPerspective(54.0f,(GLfloat)largura/(GLfloat)altura,1.0f,1000.0f);

	glMatrixMode(GL_MODELVIEW);				
	glLoadIdentity();						

	m_LarguraJanela = largura;
	m_AlturaJanela = altura;
}

void OpenGLConfig::Preparar(float dt)
{
	m_Jogo->AtualizarJogo(dt);
}

void OpenGLConfig::Renderizar()
{
	glClearColor(0.0f, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	glLoadIdentity();

	gluLookAt(m_PosicaoVista.x, m_PosicaoVista.y, m_PosicaoVista.z, 4.0, 0.0, 4.0, 0.0, 1.0, 0.0);

	//glDisable(GL_DEPTH_TEST);
	//RenderMesa();
	glEnable(GL_DEPTH_TEST);

	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
	glDepthMask(GL_FALSE);

	glEnable(GL_STENCIL_TEST);
	glStencilFunc(GL_ALWAYS, 1, 0xFFFFFFFF);
	glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);

	RenderTabuleiro();

	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	glDepthMask(GL_TRUE);

	glStencilFunc(GL_EQUAL, 1, 0xFFFFFFFF);

	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glPushMatrix();
		glScalef(1.0, -1.0, 1.0);
		RenderBonecos();
	glPopMatrix();

	glEnable(GL_BLEND);
		//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_DST_ALPHA);
		glColor4f(0.0, 0.0, 0.0, 0.1f);
		RenderTabuleiro();
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);

	glPushMatrix();
		glColor4f(1.0, 1.0, 1.0, 1.0);
		RenderBonecos();
	glPopMatrix();
}

void OpenGLConfig::RenderMesa()
{
	m_GerenciadorTexturas.Bind(m_TexturaMesa);

	glBegin(GL_TRIANGLE_STRIP);
		glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
		glTexCoord2f(10.0, 0.0);
		glVertex3f(20.0f, -0.1f, 20.0f);
		glTexCoord2f(0.0, 0.0);
		glVertex3f(-20.0f, -0.1f, 20.0f);
		glTexCoord2f(10.0, 10.0);
		glVertex3f(20.0f, -0.1f, -20.0f);
		glTexCoord2f(0.0, 10.0);
		glVertex3f(-20.0f, -0.1f, -20.0f);
	glEnd();
}

void OpenGLConfig::GerarTabuleiroDL()
{
	m_TabuleiroDL = glGenLists(1);

	glNewList(m_TabuleiroDL, GL_COMPILE);

	for (int x = 0; x < 4; x++)
		for (int z = 0; z < 4; z++)
		{
			for (int row = 2*x; row < 2*x+2; row++)
			{
				glBegin(GL_TRIANGLE_STRIP);
				for (int col = 2*z; col < 2*z+2; col++)
				{
					glTexCoord2f(row/2.0, col/2.0);
					glVertex3f(row, 0.0, col);

					glTexCoord2f((row+1)/2.0, col/2.0);
					glVertex3f(row+1, 0.0, col);

					glTexCoord2f(row/2.0, (col+1)/2.0);
					glVertex3f(row, 0.0, col+1);

					glTexCoord2f((row+1)/2.0, (col+1)/2.0);
					glVertex3f(row+1, 0.0, col+1);
				}
				glEnd();
			}		
		}

	glEndList();
}

void OpenGLConfig::RenderTabuleiro()
{
	m_GerenciadorTexturas.Bind(m_TexturaTabuleiro);
	glPushMatrix();
		glCallList(m_TabuleiroDL);
	glPopMatrix();
}

void OpenGLConfig::RenderBonecos()
{
	m_Jogo->Renderizar();
}

void OpenGLConfig::DetectarIntersecao(int winx, int winy, double &x, double &y, double &z)
{
	int viewport[4];
	double modelMatrix[16];
	double projMatrix[16];
	double nx, ny, nz;
	double fx, fy, fz;

	glGetIntegerv(GL_VIEWPORT, viewport);
	glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrix);
	glGetDoublev(GL_PROJECTION_MATRIX, projMatrix);
	gluUnProject((double)winx, (double)(viewport[3] - winy), 0.0, modelMatrix, projMatrix, viewport, &nx, &ny, &nz);
	gluUnProject((double)winx, (double)(viewport[3] - winy), 1.0, modelMatrix, projMatrix, viewport, &fx, &fy, &fz);

	CVector dir = CVector(fx, fy, fz) - CVector(nx, ny, nz);
	CVector yAxisNormal(0.0, 1.0, 0.0);
	CPlane p(yAxisNormal, 0.0);

	double pndotrd = p.N[0]*dir[0] + p.N[1]*dir[1] + p.N[2]*dir[2];
	float point = -(p.N[0] * nx + p.N[1] * ny + p.N[2] * nz + p.D) / pndotrd;

	x =  nx + (point * dir[0]);
	y =  ny + (point * dir[1]);
	z =  nz + (point * dir[2]);
}
