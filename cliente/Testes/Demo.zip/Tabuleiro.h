/*
Biblioteca para gerar o tabuleiro
*/

#ifndef __TABULEIRO_H
#define __TABULEIRO_H

const unsigned char PERSONAGEM_NULL   = 0x00;
const unsigned char PERSONAGEM_BONECO = 0x01;

class CTabuleiro
{

private:

	unsigned char  m_MatrizTabuleiro[8][8];

public:

	CTabuleiro();
	virtual ~CTabuleiro();
	void Iniciar();
	void SetarPersonagemQuadrante(int linha, int coluna, unsigned char t_personagem);
	unsigned char IdentificarPersonagemQuadrante(int linha, int coluna);
	void LimparPersonagensTabuleiro();
	void Desmontar();
};
#endif