#pragma once

#include "GameSetup.h"

class CHudInventario
{
public:
	CHudInventario(){}
};
