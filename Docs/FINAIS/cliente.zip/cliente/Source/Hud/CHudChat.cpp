#pragma once

#include "GameSetup.h"

class CHudChat
{
public:
	CHudChat(){}
};
