#pragma once

#include "GameSetup.h"

class CHudStatus
{
public:
	CHudStatus(){}
};
