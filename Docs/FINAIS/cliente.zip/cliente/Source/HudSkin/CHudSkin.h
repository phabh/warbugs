#include "CHudProgressBar.h"
#include "CHudImageSkin.h"
#include "CHudSkinLoader.h"

using namespace irr;
using namespace scene;
using namespace io;
using namespace gui;
using namespace core;
using namespace video;

