#pragma once

#include "GameSetup.h"


const stringw tituloJanela = L"Warbugs - ALPHA Version 0.1";

//-----------------------------------------------------------------------------------------
// Mensagens padr�o
//-----------------------------------------------------------------------------------------

static c8 *msg0001 = "";
static c8 *msg0002 = "";
static c8 *msg0003 = "";
static c8 *msg0004 = "";
static c8 *msg0005 = "";
static c8 *msg0006 = "";
static c8 *msg0007 = "";
static c8 *msg0008 = "";
static c8 *msg0009 = "";
static c8 *msg0010 = "";
static c8 *msg0011 = "";
static c8 *msg0012 = "";
static c8 *msg0013 = "";
static c8 *msg0014 = "";
static c8 *msg0015 = "";
static c8 *msg0016 = "";
static c8 *msg0017 = "";
static c8 *msg0018 = "";
static c8 *msg0019 = "";
static c8 *msg0020 = "";
static c8 *msg0021 = "";
static c8 *msg0022 = "";
static c8 *msg0023 = "";
static c8 *msg0024 = "";
static c8 *msg0025 = "";
static c8 *msg0026 = "";
static c8 *msg0027 = "";
static c8 *msg0028 = "";
static c8 *msg0029 = "";
static c8 *msg0030 = "";
static c8 *msg0031 = "";
static c8 *msg0032 = "";
static c8 *msg0033 = "";
static c8 *msg0034 = "";
static c8 *msg0035 = "";
static c8 *msg0036 = "";
static c8 *msg0037 = "";
static c8 *msg0038 = "";
static c8 *msg0039 = "";
static c8 *msg0040 = "";